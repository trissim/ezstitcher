"""
Utilities for working with paths in EZStitcher.

This module provides utility functions for working with paths in EZStitcher,
including functions for checking path types and converting between different
path representations.
"""

from pathlib import Path
from typing import Any, Union


def is_disk_path(path: Any) -> bool:
    """
    Determine if a path is a disk path.
    
    Args:
        path: The path to check
        
    Returns:
        True if the path is a disk path, False otherwise
    """
    # Import here to avoid circular imports
    from ezstitcher.io.virtual_path import PhysicalPath
    
    # Check if it's a string or Path object
    if isinstance(path, (str, Path)):
        return True
        
    # Check if it's a PhysicalPath
    if isinstance(path, PhysicalPath):
        return True
        
    # Check if it has a to_physical_path method that returns a non-None value
    if hasattr(path, 'to_physical_path') and callable(path.to_physical_path):
        return path.to_physical_path() is not None
        
    return False
